const express = require("express");
const bodyParser = require("body-parser");

const app = express();
app.set("key", "12345");
var key = app.get("key");
console.log(key);

// parse requests of content-type: application/json
app.use(bodyParser.json());

// parse requests of content-type: application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: true }));

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to bezkoder application." });
});

// query paramaters
app.get("/user", (req, res) => {
  var queryParamters = req.query;
  var obj = {
    req: req.body,
  };
  res.json({ queryParamters });
});

// resouce paramaters
app.get("/user/:name", (req, res) => {
  var queryParamters = req.params;
  var obj = {
    req: req.body,
  };
  res.json({ queryParamters });
});

app.get("/user/:name/:age", (req, res) => {
  var queryParamters = req.params;
  var obj = {
    req: req.body,
  };
  res.json({ queryParamters });
});

// port end points
app.post("/user", (req, res) => {
  var obj = {
    data: req.body,
  };
  res.json({ obj });
});

//https://www.youtube.com/watch?v=XNH8PQjxG8w&list=PLxoOrmZMsAWxC3BaEeSvKkqtZmfzUk367&index=13

// set port, listen for requests 80 is default
// telnet ip_adrress port hit
app.listen(3000, () => {
  console.log("Server is running on port 3000.");
});
