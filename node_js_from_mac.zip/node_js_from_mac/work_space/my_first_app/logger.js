var url = "http://google.com";

function log(message){
	console.log(message);
}

module.exports.log = log;

