var logger =  require('./logger.js')

console.log(logger);

logger.log("This is module demo")
