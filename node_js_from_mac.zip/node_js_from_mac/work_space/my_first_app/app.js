var logger = require('./logger')

console.log(logger)

function hello(){
  console.log("This is first Node js test");
}

hello();

console.log(module);

var data = "ravi";
console.log(global.data);
