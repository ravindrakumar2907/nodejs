"use strict";
// code link: https://stackify.com/aws-lambda-with-node-js-a-complete-getting-started-guide/
const Jimp = require("jimp");

module.exports.registerUser = (event, context, callback) => {
  let objectId = uuid();
  console.log("got an request " + objectId);
  let requestBody = JSON.parse(event.body);
  let firstName = requestBody.firstName;
  let lastName = requestBody.lastName;
  let email = requestBody.email;

  if (firstName !== null && firstName !== "") {
    // do something
    callback(
      null,
      constructResponse(200, "ERROR", "First name is blank or null.")
    );
  }

  if (lastName !== null && lastName !== "") {
    // do something
    callback(
      null,
      constructResponse(200, "ERROR", "Last name is blank or null.")
    );
  }

  if (email !== null && email !== "") {
    // do something
    callback(null, constructResponse(200, "ERROR", "email is blank or null."));
  }
  console.log("Going to store the user in db  objectId: " + objectId);
};

function constructResponse(statusCodeValue, errorInfo, StatusValue) {
  const response = {
    statusCode: statusCodeValue,
    headers: {
      "Access-Control-Allow-Origin": "*", // Required for CORS support to work
    },

    body: JSON.stringify({
      status: StatusValue,
      message: errorInfo,
      //input: event,
    }),
  };
}
