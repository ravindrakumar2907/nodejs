

console.log(process.argv[2])
console.log("demo")
