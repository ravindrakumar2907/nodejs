

name="ravi"
echo "This is calling js demo" + @first_arg
node mongoQ.js
